ODC AI PREDICTOR — PHONE-ONLY APK BUILD PACKAGE

What this is
- Android source project with the ODC AI PREDICTOR black-and-gold dashboard embedded locally.
- GitHub Actions workflow that builds a debug APK in the cloud.
- This ZIP is source, NOT a compiled APK.

PHONE-ONLY STEPS
1) In your phone browser, sign in to GitHub and create a new repository named ODC-AI-PREDICTOR.
2) Extract this ZIP. Upload the files and folders INSIDE this ZIP to the repository root. Make sure the .github folder is included.
3) Open the repository's Actions tab. Select “Build ODC AI PREDICTOR APK”, then tap Run workflow if it did not start automatically after upload.
4) Wait for the workflow to finish with a green check. Open the completed run and download the artifact “ODC-AI-PREDICTOR-debug-apk”.
5) Extract the downloaded artifact ZIP and tap app-debug.apk to install. Only allow installation from the browser/file manager for this APK you just built.

If Actions is disabled
- Open the repository Settings/Actions and enable GitHub Actions, then retry.
- Uploading hidden .github files can be awkward on mobile. If GitHub doesn't include .github/workflows/build-apk.yml, use Add file > Create new file and create that exact path, then paste the contents from this package's workflow file.

APP LIMITATIONS
- Manual result entry and CSV/TXT import are for local historical analysis.
- No connection to Maanwin, no live result scraping, and no guaranteed predictions. Random outcomes may not be predictable from past results.
- Debug APK is for personal testing, not Play Store publication.
